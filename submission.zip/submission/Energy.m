function [ e ] = Energy(x)

    e = sum(x.^2);

end

