function [ a ] = Area( x )
    
    a = sum(abs(x));

end

